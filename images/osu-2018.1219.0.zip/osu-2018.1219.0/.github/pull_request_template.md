Add any details pertaining to developers above the break.

- [ ] Depends on #PR
- Closes #ISSUE

---

Add a sentence or two describing this change in plain english. This will be displayed on the [changelog](https://osu.ppy.sh/home/changelog). A single screenshot or short gif is also welcomed.