---
name: Missing for Live
about: Let us know the features you need which are available in osu-stable but not lazer
---

<!-- After you fill in all information, delete all comments in the issue -->

**Describe the feature:** <!-- Describe the missing game feature -->

**Designs:** <!-- Attach screenshots of how the feature is supposed to look like. For illustrative purpose only; final designs are usually re-imagined from scratch. -->
