---
name: Feature Request
about: Let us know what you would like to see in the game!
---

<!-- After you fill in all information, delete all comments in the issue -->

**Describe the feature:** <!-- Describe the feature you would like to see in the game -->

**Proposal designs of the feature:** <!-- Attach screenshots of how the feature should look like according to you -->
