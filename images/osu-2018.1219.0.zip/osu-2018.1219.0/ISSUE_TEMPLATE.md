osu!lazer is currently still under heavy development!

Please ensure that you are making an issue for one of the following:

- A bug with currently implemented features (not features that don't exist)
- A feature you are considering adding, so we can collaborate on feedback and design.
- Discussions about technical design decisions

If your issue qualifies, replace this text with a detailed description of your issue with as much relevant information as you can provide.

Screenshots and log files are highly welcomed.